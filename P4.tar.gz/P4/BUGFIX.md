# Changelog - Bug Fix

## Issue Fixed
The server was experiencing "Interrupted system call" errors when accepting connections. This happened because the SIGCHLD signal handler (used to reap child processes) was interrupting the `accept()` system calls.

## Solution
Added proper signal handling to retry `accept()` when interrupted:

1. Added `#include <errno.h>` for EINTR constant
2. Modified both `accept()` calls to retry when interrupted by signals:
   ```c
   int p1_fd;
   while ((p1_fd = accept(server_fd, NULL, NULL)) < 0)
   {
       if (errno == EINTR)
           continue;  // Interrupted by signal, retry
       perror("Player 1 connection failed");
       break;
   }
   if (p1_fd < 0)
       continue;
   ```

This is a standard practice when using signal handlers with blocking system calls.

## What This Fixes
- ✅ Players can now connect reliably
- ✅ Concurrent games work properly
- ✅ SIGCHLD handler no longer breaks accept()
- ✅ Server remains stable under load

## Testing
After extracting the new archive:
```bash
tar -xzf P4.tar.gz
cd P4
make clean
make all
./verify_test.sh
```

You should now see successful connections instead of "Interrupted system call" errors.
