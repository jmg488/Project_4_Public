# Quick Start Guide

## What You Have

I've created a **complete concurrent Nim game server with all extra credit features** for your CS213 project.

## Download and Extract

```bash
# Extract the archive
tar -xzf P4.tar.gz
cd P4
```

## Build

```bash
make all
```

This creates:
- `nimd_concurrent` - The concurrent server (your main submission)
- `testc` - Interactive test client (easy to use)
- `rawc` - Raw protocol client (for manual testing)

## Quick Test

### Terminal 1 - Start Server
```bash
./nimd_concurrent 5555
```

### Terminal 2 - Player 1
```bash
./testc localhost 5555 Alice
```

### Terminal 3 - Player 2  
```bash
./testc localhost 5555 Bob
```

The game will start automatically. When it's your turn, type:
```
pile stones
```

For example: `2 3` removes 3 stones from pile 2 (0-indexed: pile 0,1,2,3,4).

## Testing Extra Credit

### Feature 1: Out-of-Turn Detection
- When it's Player 1's turn, have Player 2 try to enter a move
- You'll see: `>> ERROR FROM SERVER: 0|24|FAIL|31 Impatient|`
- Game continues normally

### Feature 2: Duplicate Player Prevention
- While a game is active, open a 4th terminal
- Try: `./testc localhost 5555 Alice` (same name as active player)
- Connection rejected with "22 Already Playing"

### Feature 3: Immediate Forfeit
- During an active game, press Ctrl+C in one terminal
- The other player immediately sees: `>> YOU WIN! (by forfeit)`
- No waiting for the next move

### Concurrent Games Test
Open 4 terminals at once:
```bash
# Terminal 1
./testc localhost 5555 Alice

# Terminal 2
./testc localhost 5555 Bob

# Terminal 3
./testc localhost 5555 Carol

# Terminal 4
./testc localhost 5555 Dave
```

Result: Two independent games run simultaneously!
- Alice vs Bob
- Carol vs Dave

## Before Submitting

1. **Update AUTHOR file** with your NetID(s)
2. **Update README.md** - add your name at the top
3. **Test thoroughly** - run through the test plan in README.md
4. **Create submission archive**:
   ```bash
   cd ..
   tar -czf P4_submission.tar.gz P4/
   ```

## What's Implemented

✅ Single game (70 pts) - Complete
✅ Concurrent games (100 pts) - Fork-based with shared memory  
✅ Extra credit (+20 pts) - All three features:
   - Poll-based immediate message handling
   - Out-of-turn detection (Impatient error)
   - Immediate forfeit on disconnection

## File Overview

**Core Implementation:**
- `nimd_concurrent.c` - Main server (17KB, ~570 lines)
- `network.c/h` - TCP utilities (provided)

**Testing Tools:**
- `testc.c` - User-friendly interactive client
- `rawc.c` - Raw protocol testing client
- `test_server.sh` - Quick test script

**Documentation:**
- `README.md` - Complete documentation with test plan
- `IMPLEMENTATION.md` - Detailed implementation notes
- `AUTHOR` - Your NetID (UPDATE THIS!)

## Key Features

1. **Fork-based concurrency** - Each game in separate process
2. **Shared memory** - Tracks active players across processes
3. **Poll-based I/O** - Monitors both players simultaneously
4. **Complete error handling** - All NGP error codes implemented
5. **Robust parsing** - Validates all message formats
6. **Graceful cleanup** - SIGCHLD handler reaps children

## Architecture

```
nimd_concurrent (parent)
    |
    +-- fork() → Game 1 (Alice vs Bob)
    |              |-- poll(p1, p2)
    |              |-- PLAY → both
    |              |-- MOVE ← current player
    |              +-- OVER → both
    |
    +-- fork() → Game 2 (Carol vs Dave)
    |              |-- poll(p3, p4)
    |              |-- ...
    |              +-- OVER → both
    |
    +-- continue accepting new players...
```

## Common Issues

**Port already in use:**
```bash
# Use a different port
./nimd_concurrent 5556
```

**Can't connect:**
- Make sure server is running first
- Check firewall settings
- Try `localhost` or `127.0.0.1`

**Compilation errors:**
```bash
make clean
make all
```

## Grade Breakdown

- **Single game:** 70 points - ✅ Implemented
- **Concurrent games:** +30 points - ✅ Implemented  
- **Extra credit:** +20 points - ✅ Implemented

**Total possible: 120/100 points**

## Need Help?

1. Read `README.md` for detailed documentation
2. Read `IMPLEMENTATION.md` for design details
3. Check test plan in README.md
4. Run `./test_server.sh` for guided testing

Good luck with your submission!
