int connect_inet(char *host, char *service);
int open_listener(char *service, int queue_size);
