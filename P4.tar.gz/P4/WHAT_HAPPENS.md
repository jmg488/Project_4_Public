# What Happens After `make all`

## Expected Output

When you run `make all`, you should see:

```bash
$ make all
gcc -g -Wall -std=c99 -fsanitize=address,undefined -c nimd_concurrent.c
gcc -g -Wall -std=c99 -fsanitize=address,undefined -c network.c
gcc -g -Wall -std=c99 -fsanitize=address,undefined -o nimd_concurrent nimd_concurrent.o network.o
gcc -g -Wall -std=c99 -fsanitize=address,undefined -c rawc.c
gcc -g -Wall -std=c99 -fsanitize=address,undefined -c pbuf.c
gcc -g -Wall -std=c99 -fsanitize=address,undefined -o rawc rawc.o pbuf.o network.o
gcc -g -Wall -std=c99 -fsanitize=address,undefined -c testc.c
testc.c: In function 'main':
testc.c:53:9: warning: variable 'my_turn' set but not used [-Wunused-but-set-variable]
   53 |     int my_turn = 0;
      |         ^~~~~~~
gcc -g -Wall -std=c99 -fsanitize=address,undefined -o testc testc.o network.o
```

## What Gets Created

After `make all` completes, you'll have these **executables**:

```bash
$ ls -lh
-rwxr-xr-x  nimd_concurrent  # Your main server (160KB)
-rwxr-xr-x  rawc             # Raw protocol client (58KB)
-rwxr-xr-x  testc            # Interactive test client (82KB)
```

And these **object files** (used during compilation):

```bash
nimd_concurrent.o
network.o
pbuf.o
rawc.o
testc.o
```

## Testing the Build

Verify everything compiled correctly:

```bash
$ ./nimd_concurrent
Usage: ./nimd_concurrent <port>

$ ./testc
Usage: ./testc host port player_name

$ ./rawc
Usage: ./rawc host port
```

All three should print their usage messages, confirming they're working.

## The Warning is OK

The warning about `my_turn` being unused is harmless:
```
testc.c:53:9: warning: variable 'my_turn' set but not used
```

This is just a tracking variable I kept in the code. It doesn't affect functionality.

## If You Get Errors

### "No rule to make target 'nimd.c'"
- **Cause:** Wrong Makefile version
- **Fix:** Make sure you're using the updated Makefile (doesn't reference nimd.c)

### "network.h: No such file or directory"
- **Cause:** Missing files
- **Fix:** Make sure you extracted all files from P4.tar.gz

### Compilation errors about undefined functions
- **Cause:** Missing source files
- **Fix:** Ensure network.c, pbuf.c are present

## Next Step: Run the Server

Once compilation succeeds, start the server:

```bash
$ ./nimd_concurrent 5555
[SERVER] Listening on port 5555
[SERVER] Concurrent game mode with extra credit enabled
[SERVER] Waiting for Player 1...
```

The server will wait for clients to connect.

## Connect Clients (In Other Terminals)

**Terminal 2:**
```bash
$ ./testc localhost 5555 Alice
Connected to localhost:5555
Playing as: Alice
Sending: 0|14|OPEN|Alice|
Received: 0|05|WAIT|
>> Waiting for opponent...
```

**Terminal 3:**
```bash
$ ./testc localhost 5555 Bob
Connected to localhost:5555
Playing as: Bob
Sending: 0|12|OPEN|Bob|
Received: 0|13|NAME|1|Bob|
>> You are Player 2, opponent: Alice
Received: 0|17|PLAY|1|1 3 5 7 9|
>> Board: 1 3 5 7 9
>> Waiting for opponent's move...
```

**Terminal 2 (Alice sees):**
```bash
Received: 0|15|NAME|2|Alice|
>> You are Player 1, opponent: Bob
Received: 0|17|PLAY|1|1 3 5 7 9|
>> Board: 1 3 5 7 9
>> YOUR TURN! Enter move as 'pile stones' (e.g., '2 3'): 
```

## Full File Structure After Build

```
P4/
├── nimd_concurrent      ← EXECUTABLE (your server)
├── testc                ← EXECUTABLE (test client)
├── rawc                 ← EXECUTABLE (raw client)
├── nimd_concurrent.o    ← Object file
├── network.o            ← Object file
├── pbuf.o               ← Object file
├── rawc.o               ← Object file
├── testc.o              ← Object file
├── nimd_concurrent.c    ← Source code
├── testc.c              ← Source code
├── rawc.c               ← Source code
├── network.c            ← Source code
├── network.h            ← Header
├── pbuf.c               ← Source code
├── pbuf.h               ← Header
├── Makefile             ← Build script
├── README.md            ← Documentation
├── QUICKSTART.md        ← Quick guide
├── IMPLEMENTATION.md    ← Technical details
├── PROTOCOL_FLOWS.md    ← Protocol diagrams
├── test_server.sh       ← Test script
└── AUTHOR               ← Your NetID
```

## Troubleshooting

### Issue: "Permission denied" when running executables
**On Linux/Mac:**
```bash
chmod +x nimd_concurrent testc rawc
```

### Issue: Compiler warnings about sanitizer
This is normal with `-fsanitize=address,undefined`. It's a good thing - helps catch bugs!

### Issue: Make says "up to date"
Already compiled! Either run your programs or:
```bash
make clean
make all
```

## Summary

✅ **Success looks like:**
- 3 executables created (nimd_concurrent, testc, rawc)
- 5 object files created (.o files)
- One harmless warning about unused variable
- Programs run and show usage messages

❌ **Failure looks like:**
- "Error" messages during compilation
- "undefined reference" errors
- Programs don't exist after make
- Can't run the executables

If successful, proceed to testing! See QUICKSTART.md for next steps.
