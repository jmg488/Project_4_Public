# Automated Testing Script

## Quick Start

```bash
chmod +x test_all.sh
./test_all.sh
```

That's it! The script will automatically test everything.

## What It Tests

The script runs **all** tests automatically:

### ✓ Basic Game (70 points)
- Server accepts connections
- NAME messages sent
- PLAY messages sent
- MOVE messages processed
- Win condition detected
- OVER message sent

### ✓ Concurrent Games (100 points)
- Two games run simultaneously
- Games don't interfere
- Duplicate player names rejected (error 22)

### ✓ Extra Credit (+20 points)
- Out-of-turn detection (error 31 Impatient)
- Immediate forfeit on disconnect
- OVER with Forfeit flag sent

### ✓ Error Handling
- Invalid pile index (error 32)
- Invalid quantity (error 33)
- Long names (error 21)

## Expected Output

```
========================================
NIM GAME SERVER TEST SUITE
========================================

Testing: nimd_concurrent
Port: 5556

========================================
TEST 1: Basic Game Flow (70 points)
========================================

TEST: 1.1: Server accepts connections and starts game
✓ PASS: Complete game played, winner declared
✓ PASS: NAME messages sent to both players
✓ PASS: PLAY messages with board state sent

========================================
TEST 2: Concurrent Games (100 points)
========================================

TEST: 2.1: Two games run simultaneously
✓ PASS: Two concurrent games started successfully
✓ PASS: Server forked processes for concurrent games

... (more tests)

========================================
TEST SUMMARY
========================================

Tests Passed: 12 / 12
Tests Failed: 0 / 12

========================================
ALL TESTS PASSED! ✓
========================================

Your implementation includes:
  ✓ Basic game functionality (70 points)
  ✓ Concurrent games (100 points)
  ✓ Extra credit features (+20 points)

Ready to submit!
```

## What If Tests Fail?

The script creates log files for debugging:

```bash
ls *.log
```

You'll see:
- `server.log` - Server output
- `p1.log`, `p2.log` - Player outputs
- `game1_p1.log`, etc. - Concurrent game outputs
- `impatient_p1.log` - Out-of-turn test
- `forfeit_p2.log` - Forfeit test
- And more...

Check these files to see what went wrong:

```bash
cat server.log       # Server-side view
cat p1.log           # Player 1 view
cat impatient_p2.log # See the impatient error
```

## Manual Testing

If you want to test manually instead:

### Basic Game
```bash
# Terminal 1
./nimd_concurrent 5555

# Terminal 2
./testc localhost 5555 Alice

# Terminal 3
./testc localhost 5555 Bob
```

### Concurrent Games
```bash
# Start server in Terminal 1
./nimd_concurrent 5555

# Connect 4 players in different terminals
./testc localhost 5555 Alice
./testc localhost 5555 Bob
./testc localhost 5555 Carol
./testc localhost 5555 Dave
```

### Test Extra Credit Features

**Impatient Error:**
- Start game (Alice vs Bob)
- When it's Player 1's turn, have Player 2 try to move
- Player 2 gets "31 Impatient"

**Forfeit:**
- Start game
- Press Ctrl+C in one player's terminal
- Other player immediately wins by forfeit

## Cleanup

The script cleans up after itself, but if you need to:

```bash
# Kill any remaining processes
pkill -f nimd_concurrent
pkill -f testc

# Remove log files
rm -f *.log
```

## Troubleshooting

**"Address already in use"**
```bash
# Kill any process using the port
pkill -f nimd_concurrent
sleep 1
./test_all.sh
```

**"Permission denied"**
```bash
chmod +x test_all.sh
./test_all.sh
```

**Script hangs**
- Press Ctrl+C to stop
- Run: `pkill -f testc; pkill -f nimd_concurrent`
- Try again

## Time Required

The script takes about **30-40 seconds** to run all tests.

## Exit Codes

- `0` - All tests passed
- `>0` - Number of tests that failed

Use in scripts:
```bash
./test_all.sh
if [ $? -eq 0 ]; then
    echo "All good!"
else
    echo "Some tests failed"
fi
```
