#!/bin/bash
# Comprehensive test script for nimd_concurrent
# Tests all features: basic game, concurrent games, and extra credit

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test results
TESTS_PASSED=0
TESTS_FAILED=0

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_test() {
    echo -e "${YELLOW}TEST: $1${NC}"
}

print_pass() {
    echo -e "${GREEN}✓ PASS: $1${NC}"
    ((TESTS_PASSED++))
}

print_fail() {
    echo -e "${RED}✗ FAIL: $1${NC}"
    ((TESTS_FAILED++))
}

print_info() {
    echo -e "  $1"
}

# Check if executables exist
if [ ! -f "./nimd_concurrent" ]; then
    echo -e "${RED}Error: nimd_concurrent not found. Run 'make all' first.${NC}"
    exit 1
fi

if [ ! -f "./testc" ]; then
    echo -e "${RED}Error: testc not found. Run 'make all' first.${NC}"
    exit 1
fi

PORT=5556
SERVER_PID=""

cleanup() {
    if [ ! -z "$SERVER_PID" ]; then
        kill $SERVER_PID 2>/dev/null
        wait $SERVER_PID 2>/dev/null
    fi
    # Kill any remaining testc processes
    pkill -f "testc localhost $PORT" 2>/dev/null
    sleep 0.5
}

start_server() {
    cleanup
    ./nimd_concurrent $PORT > server.log 2>&1 &
    SERVER_PID=$!
    sleep 0.5
    
    if ! ps -p $SERVER_PID > /dev/null; then
        print_fail "Server failed to start"
        return 1
    fi
    return 0
}

# Trap to cleanup on exit
trap cleanup EXIT INT TERM

print_header "NIM GAME SERVER TEST SUITE"
echo "Testing: nimd_concurrent"
echo "Port: $PORT"
echo ""

#############################################################################
print_header "TEST 1: Basic Game Flow (70 points)"
#############################################################################

print_test "1.1: Server accepts connections and starts game"
start_server
if [ $? -eq 0 ]; then
    # Start two players
    (sleep 0.5; echo "4 9"; sleep 1; echo "2 5"; sleep 1; echo "0 1") | ./testc localhost $PORT Alice > p1.log 2>&1 &
    P1_PID=$!
    
    (sleep 0.5; echo "3 7"; sleep 1; echo "1 3") | ./testc localhost $PORT Bob > p2.log 2>&1 &
    P2_PID=$!
    
    # Wait for game to complete
    sleep 5
    
    # Check if game completed
    if grep -q "YOU WIN" p1.log; then
        print_pass "Complete game played, winner declared"
    elif grep -q "YOU LOSE" p2.log; then
        print_pass "Complete game played, winner declared"
    else
        print_fail "Game did not complete properly"
        print_info "Check p1.log and p2.log for details"
    fi
    
    # Check for NAME messages
    if grep -q "You are Player" p1.log && grep -q "You are Player" p2.log; then
        print_pass "NAME messages sent to both players"
    else
        print_fail "NAME messages not received"
    fi
    
    # Check for PLAY messages
    if grep -q "Board:" p1.log && grep -q "Board:" p2.log; then
        print_pass "PLAY messages with board state sent"
    else
        print_fail "PLAY messages not received"
    fi
    
    cleanup
else
    print_fail "Server failed to start"
fi

#############################################################################
print_header "TEST 2: Concurrent Games (100 points)"
#############################################################################

print_test "2.1: Two games run simultaneously"
start_server

# Start Game 1: Alice vs Bob
(sleep 0.5; echo "4 5"; sleep 2; echo "0 1") | ./testc localhost $PORT Alice > game1_p1.log 2>&1 &
(sleep 0.5; echo "3 5") | ./testc localhost $PORT Bob > game1_p2.log 2>&1 &

# Start Game 2: Carol vs Dave
sleep 0.2
(sleep 0.5; echo "4 7"; sleep 2; echo "0 1") | ./testc localhost $PORT Carol > game2_p1.log 2>&1 &
(sleep 0.5; echo "3 3") | ./testc localhost $PORT Dave > game2_p2.log 2>&1 &

# Wait for games
sleep 5

# Check if both games started
if grep -q "You are Player" game1_p1.log && grep -q "You are Player" game2_p1.log; then
    print_pass "Two concurrent games started successfully"
    
    # Check server log for fork messages
    if grep -q "Forked game process" server.log; then
        print_pass "Server forked processes for concurrent games"
    else
        print_info "Note: Check if server is using fork()"
    fi
else
    print_fail "Concurrent games did not start properly"
    print_info "Check game1_p1.log and game2_p1.log"
fi

cleanup

#############################################################################
print_header "TEST 3: Duplicate Player Prevention (Concurrent)"
#############################################################################

print_test "3.1: Reject duplicate player name during active game"
start_server

# Start game with Alice and Bob
(sleep 0.5; sleep 10) | ./testc localhost $PORT Alice > dup_p1.log 2>&1 &
(sleep 0.5; sleep 10) | ./testc localhost $PORT Bob > dup_p2.log 2>&1 &

sleep 1

# Try to connect another Alice
echo "" | timeout 2 ./testc localhost $PORT Alice > dup_test.log 2>&1

# Check for rejection
if grep -q "22 Already Playing" dup_test.log; then
    print_pass "Duplicate player rejected with error code 22"
else
    print_fail "Duplicate player not properly rejected"
    print_info "Expected: 22 Already Playing"
    print_info "Check dup_test.log for details"
fi

cleanup

#############################################################################
print_header "TEST 4: Out-of-Turn Detection (Extra Credit)"
#############################################################################

print_test "4.1: Detect and reject out-of-turn MOVE (31 Impatient)"
start_server

# Create a script that sends moves for both players
# Alice (P1) will wait, Bob (P2) will try to move first

cat > player1_script.sh << 'EOF'
#!/bin/bash
sleep 3  # Wait for Bob to send impatient move
echo "4 9"
sleep 1
echo "2 5"
EOF
chmod +x player1_script.sh

cat > player2_script.sh << 'EOF'
#!/bin/bash
sleep 1  # Try to move when it's not our turn
echo "3 7"
sleep 3
echo "1 3"
EOF
chmod +x player2_script.sh

./player1_script.sh | ./testc localhost $PORT Alice > impatient_p1.log 2>&1 &
./player2_script.sh | ./testc localhost $PORT Bob > impatient_p2.log 2>&1 &

sleep 6

# Check if Bob got Impatient error
if grep -q "31 Impatient" impatient_p2.log; then
    print_pass "Out-of-turn move detected, error 31 sent"
else
    print_fail "Out-of-turn move not detected"
    print_info "Expected: 31 Impatient error"
    print_info "Check impatient_p2.log for details"
fi

# Check if game continued after impatient error
if grep -q "Board:" impatient_p1.log; then
    print_pass "Game continued after impatient error"
else
    print_info "Note: Verify game continued normally"
fi

rm -f player1_script.sh player2_script.sh
cleanup

#############################################################################
print_header "TEST 5: Immediate Forfeit Detection (Extra Credit)"
#############################################################################

print_test "5.1: Detect disconnection and award forfeit win"
start_server

# Start game where Alice will disconnect
(sleep 1; exit 0) | ./testc localhost $PORT Alice > forfeit_p1.log 2>&1 &
ALICE_PID=$!

(sleep 0.5; sleep 5) | ./testc localhost $PORT Bob > forfeit_p2.log 2>&1 &
BOB_PID=$!

sleep 3

# Check if Bob got forfeit win
if grep -q "Forfeit" forfeit_p2.log && grep -q "YOU WIN" forfeit_p2.log; then
    print_pass "Forfeit detected, remaining player won"
else
    print_fail "Forfeit not properly handled"
    print_info "Expected: OVER message with Forfeit flag"
    print_info "Check forfeit_p2.log for details"
fi

cleanup

#############################################################################
print_header "TEST 6: Invalid Move Validation"
#############################################################################

print_test "6.1: Invalid pile index (error 32)"
start_server

# Use rawc or create a test that sends invalid move
cat > invalid_pile.sh << 'EOF'
#!/bin/bash
sleep 1
echo "5 3"  # Pile 5 doesn't exist (0-4 valid)
EOF
chmod +x invalid_pile.sh

./invalid_pile.sh | ./testc localhost $PORT Alice > invalid_p1.log 2>&1 &
(sleep 0.5; sleep 3) | ./testc localhost $PORT Bob > invalid_p2.log 2>&1 &

sleep 4

if grep -q "32 Pile Index" invalid_p1.log; then
    print_pass "Invalid pile index rejected (error 32)"
else
    print_info "Note: Verify pile index validation (error 32)"
fi

rm -f invalid_pile.sh
cleanup

print_test "6.2: Invalid quantity (error 33)"
start_server

cat > invalid_qty.sh << 'EOF'
#!/bin/bash
sleep 1
echo "4 99"  # Pile 4 only has 9 stones
EOF
chmod +x invalid_qty.sh

./invalid_qty.sh | ./testc localhost $PORT Alice > qty_p1.log 2>&1 &
(sleep 0.5; sleep 3) | ./testc localhost $PORT Bob > qty_p2.log 2>&1 &

sleep 4

if grep -q "33 Quantity" qty_p1.log; then
    print_pass "Invalid quantity rejected (error 33)"
else
    print_info "Note: Verify quantity validation (error 33)"
fi

rm -f invalid_qty.sh
cleanup

#############################################################################
print_header "TEST 7: Name Validation"
#############################################################################

print_test "7.1: Reject overly long names (error 21)"
start_server

# Try to connect with very long name (>72 chars)
LONG_NAME="ThisNameIsWayTooLongAndExceedsTheSeventyTwoCharacterLimitSetByTheProtocol"
echo "" | timeout 2 ./testc localhost $PORT "$LONG_NAME" > longname.log 2>&1

if grep -q "21 Long Name" longname.log; then
    print_pass "Long name rejected (error 21)"
else
    print_info "Note: Verify name length validation (error 21)"
fi

cleanup

#############################################################################
print_header "TEST SUMMARY"
#############################################################################

TOTAL_TESTS=$((TESTS_PASSED + TESTS_FAILED))
echo ""
echo "Tests Passed: ${GREEN}$TESTS_PASSED${NC} / $TOTAL_TESTS"
echo "Tests Failed: ${RED}$TESTS_FAILED${NC} / $TOTAL_TESTS"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}ALL TESTS PASSED! ✓${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo "Your implementation includes:"
    echo "  ✓ Basic game functionality (70 points)"
    echo "  ✓ Concurrent games (100 points)"
    echo "  ✓ Extra credit features (+20 points)"
    echo ""
    echo -e "${GREEN}Ready to submit!${NC}"
    echo ""
else
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}Some tests failed or need verification${NC}"
    echo -e "${YELLOW}========================================${NC}"
    echo ""
    echo "Check the log files for details:"
    echo "  - server.log (server output)"
    echo "  - *.log (test client outputs)"
    echo ""
fi

# Cleanup log files
echo "Log files saved for review:"
ls -1 *.log 2>/dev/null | sed 's/^/  - /'
echo ""

exit $TESTS_FAILED
