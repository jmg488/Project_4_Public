void print_buffer(char *, unsigned int);
