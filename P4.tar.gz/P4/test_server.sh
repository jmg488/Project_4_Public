#!/bin/bash
# Test script for nimd_concurrent
# This demonstrates the concurrent server with extra credit features

echo "=== Nim Game Server Test Suite ==="
echo

# Check if server is compiled
if [ ! -f "./nimd_concurrent" ]; then
    echo "Error: nimd_concurrent not found. Run 'make' first."
    exit 1
fi

if [ ! -f "./testc" ]; then
    echo "Error: testc not found. Run 'make' first."
    exit 1
fi

PORT=5555

echo "Test 1: Server Startup"
echo "----------------------"
echo "Starting server on port $PORT..."
echo "Run in another terminal:"
echo "  ./testc localhost $PORT Alice"
echo "  ./testc localhost $PORT Bob"
echo
echo "To test concurrent games, open 4 terminals and connect:"
echo "  Terminal 1: ./testc localhost $PORT Alice"
echo "  Terminal 2: ./testc localhost $PORT Bob"
echo "  Terminal 3: ./testc localhost $PORT Carol"
echo "  Terminal 4: ./testc localhost $PORT Dave"
echo
echo "Extra Credit Features to Test:"
echo "1. Out-of-Turn Detection:"
echo "   - When it's Player 1's turn, have Player 2 try to move"
echo "   - Server should respond with FAIL 31 Impatient"
echo
echo "2. Duplicate Player Prevention:"
echo "   - While Alice and Bob are playing, try to connect another 'Alice'"
echo "   - Server should respond with FAIL 22 Already Playing"
echo
echo "3. Immediate Forfeit:"
echo "   - During a game, disconnect one player (Ctrl+C)"
echo "   - Other player should immediately receive OVER with Forfeit"
echo
echo "Starting server..."
./nimd_concurrent $PORT
