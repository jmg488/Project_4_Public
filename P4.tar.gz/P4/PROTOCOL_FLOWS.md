# NGP Protocol Flow Diagram

## Normal Game Flow

```
Client 1                Server                Client 2
   |                       |                       |
   |  0|14|OPEN|Alice|     |                       |
   |---------------------->|                       |
   |                       |                       |
   |     0|05|WAIT|        |                       |
   |<----------------------|                       |
   |                       |                       |
   |                       |   0|12|OPEN|Bob|      |
   |                       |<----------------------|
   |                       |                       |
   |  0|13|NAME|1|Bob|     |    0|15|NAME|2|Alice||
   |<----------------------|---------------------->|
   |                       |                       |
   | 0|17|PLAY|1|1 3 5 7 9||  0|17|PLAY|1|1 3 5 7 9||
   |<----------------------|---------------------->|
   |                       |                       |
   | 0|09|MOVE|4|5|        |                       |
   |---------------------->|                       |
   |                       |                       |
   | 0|17|PLAY|2|1 3 5 7 4||  0|17|PLAY|2|1 3 5 7 4||
   |<----------------------|---------------------->|
   |                       |                       |
   |                       |    0|09|MOVE|3|5|     |
   |                       |<----------------------|
   |                       |                       |
   | 0|17|PLAY|1|1 3 0 7 4||  0|17|PLAY|1|1 3 0 7 4||
   |<----------------------|---------------------->|
   |                       |                       |
   |         ...           |         ...           |
   |                       |                       |
   | 0|18|OVER|1|0 0 0 0 0|||  0|18|OVER|1|0 0 0 0 0|||
   |<----------------------|---------------------->|
   |                       |                       |
  [Disconnect]            [Close]              [Disconnect]
```

## Extra Credit: Out-of-Turn Detection

```
Client 1 (Turn)         Server            Client 2 (Waiting)
   |                       |                       |
   | 0|17|PLAY|1|1 3 5 7 9||  0|17|PLAY|1|1 3 5 7 9||
   |<----------------------|---------------------->|
   |                       |                       |
   |    (thinking...)      |    0|09|MOVE|2|3|     |
   |                       |<------- WRONG PLAYER! |
   |                       |                       |
   |                       |   0|24|FAIL|31 Impatient||
   |                       |---------------------->|
   |                       |                       |
   | 0|09|MOVE|4|5|        |                       |
   |-------- CORRECT! ---->|                       |
   |                       |                       |
   | 0|17|PLAY|2|1 3 5 7 4||  0|17|PLAY|2|1 3 5 7 4||
   |<----------------------|---------------------->|
```

## Extra Credit: Immediate Forfeit Detection

```
Client 1                Server                Client 2
   |                       |                       |
   | 0|17|PLAY|1|1 3 5 7 9||  0|17|PLAY|1|1 3 5 7 9||
   |<----------------------|---------------------->|
   |                       |                       |
   |    (thinking...)      |                       |
   |                       |                   [Disconnect!]
   |                       |<--------X             |
   |                       |                       |
   |  [poll() detects!]    |                       |
   |                       |                       |
   | 0|25|OVER|1|1 3 5 7 9|Forfeit||               |
   |<----------------------|                       |
   |                       |                       |
  [Disconnect]            [Close]                  X
```

## Concurrent Games

```
Main Process                Child Process 1           Child Process 2
     |                              |                          |
     +-- accept() Alice             |                          |
     +-- accept() Bob               |                          |
     |                              |                          |
     +-- fork() ------------------> |                          |
     +-- close(Alice, Bob)          |                          |
     |                       handle_game(Alice, Bob)           |
     +-- accept() Carol             |                          |
     +-- accept() Dave              |                          |
     |                              |                          |
     +-- fork() ----------------------------------> handle_game(Carol, Dave)
     +-- close(Carol, Dave)         |                          |
     |                              |                          |
     +-- continue accepting...      |                          |
                                    |                          |
                             [Alice vs Bob]            [Carol vs Dave]
                                    |                          |
                                 exit(0)                    exit(0)
```

## Shared Memory for Player Tracking

```
┌─────────────────────────────────────┐
│      Shared Memory (mmap)           │
│                                     │
│  Active Players:                    │
│  ┌────────────────────┐            │
│  │ [0] "Alice"        │            │
│  │ [1] "Bob"          │            │
│  │ [2] "Carol"        │            │
│  │ [3] "Dave"         │            │
│  │ ...                │            │
│  └────────────────────┘            │
│  Count: 4                          │
└─────────────────────────────────────┘
         ↑              ↑
         |              |
    Parent Process   Child Processes
    (when accepting)  (during games)
    
• Checks before matching new players
• Adds players when game starts
• Removes players when game ends
• Visible to all processes
```

## Message Validation Flow

```
Incoming Message
      |
      v
┌─────────────────────┐
│ Check version = "0" │ → Error: Invalid
└─────────────────────┘
      |
      v
┌─────────────────────┐
│ Parse length field  │ → Error: Invalid
└─────────────────────┘
      |
      v
┌─────────────────────┐
│ Check message type  │ → Error: Invalid
└─────────────────────┘
      |
      v
┌─────────────────────┐
│ Validate fields     │ → Error: Specific
└─────────────────────┘     (21, 22, 32, 33, etc.)
      |
      v
┌─────────────────────┐
│ Check game state    │ → Error: 24, 31
└─────────────────────┘
      |
      v
┌─────────────────────┐
│ Process message     │
└─────────────────────┘
```

## Error Handling Decision Tree

```
Message arrives
      |
      ├─ Can't parse? → FAIL 10 Invalid → Close
      |
      ├─ OPEN received?
      |     ├─ Name > 72 chars? → FAIL 21 Long Name → Close
      |     ├─ Name has pipe? → FAIL 10 Invalid → Close
      |     ├─ Already active? → FAIL 22 Already Playing → Close
      |     ├─ Already opened? → FAIL 23 Already Open → Close
      |     └─ OK → Add to waiting queue
      |
      ├─ MOVE received?
      |     ├─ Game not started? → FAIL 24 Not Playing → Close
      |     ├─ Not player's turn? → FAIL 31 Impatient → Continue
      |     ├─ Pile index bad? → FAIL 32 Pile Index → Continue
      |     ├─ Quantity bad? → FAIL 33 Quantity → Continue
      |     └─ OK → Apply move, check win
      |
      └─ Other message? → Ignore or FAIL 10 Invalid
```

## State Machine

```
┌──────────┐   OPEN    ┌──────────┐   Matched   ┌──────────┐
│   New    │---------->│ Waiting  │------------>│  Named   │
│Connection│           │ for pair │             │ (Player) │
└──────────┘           └──────────┘             └──────────┘
                                                      |
                            PLAY (turn indication)    |
                                                      v
                       ┌────────────────────────────────┐
                       │        Playing Game            │
                       │  ┌──────────────────────┐     │
                       │  │  Wait for MOVE       │     │
                       │  │  (via poll on both)  │     │
                       │  └──────────────────────┘     │
                       │           |                    │
                       │           v                    │
                       │  ┌──────────────────────┐     │
                       │  │  Validate & Apply    │     │
                       │  └──────────────────────┘     │
                       │           |                    │
                       │           v                    │
                       │  ┌──────────────────────┐     │
                       │  │   Check Win/Forfeit  │     │
                       │  └──────────────────────┘     │
                       └────────────────────────────────┘
                                     |
                              OVER message sent
                                     |
                                     v
                              ┌──────────┐
                              │   Done   │
                              │ (Close)  │
                              └──────────┘
```

## Game Board Updates

```
Initial Board:  [1, 3, 5, 7, 9]

Player 1 Move: Remove 5 from pile 4
   MOVE|4|5|
   
Updated Board:  [1, 3, 5, 7, 4]

Player 2 Move: Remove 5 from pile 3
   MOVE|3|5|
   
Updated Board:  [1, 3, 0, 7, 4]

... continue until ...

Final Board:    [0, 0, 0, 0, 0]  → Winner!
```

## Poll Loop (Extra Credit)

```
┌──────────────────────────────────────────┐
│           Game Main Loop                 │
├──────────────────────────────────────────┤
│                                          │
│  1. Send PLAY to both players           │
│                                          │
│  2. poll(p1_fd, p2_fd, timeout=-1)      │
│                                          │
│  3. Check which fd has data:            │
│     ┌────────────────────────────┐     │
│     │ p2_fd ready but p1's turn? │     │
│     │ → FAIL 31 Impatient        │     │
│     │ → continue waiting          │     │
│     └────────────────────────────┘     │
│                                          │
│     ┌────────────────────────────┐     │
│     │ p1_fd ready and p1's turn? │     │
│     │ → Read and validate MOVE   │     │
│     │ → Apply to board           │     │
│     │ → Check win                │     │
│     │ → Switch turns             │     │
│     └────────────────────────────┘     │
│                                          │
│     ┌────────────────────────────┐     │
│     │ Either fd shows EOF?       │     │
│     │ → Immediate forfeit        │     │
│     │ → OVER to other player     │     │
│     │ → Exit game               │     │
│     └────────────────────────────┘     │
│                                          │
│  4. Loop until board empty              │
│                                          │
└──────────────────────────────────────────┘
```
